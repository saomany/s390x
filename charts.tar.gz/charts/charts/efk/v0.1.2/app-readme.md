# EFK

EFK(Elasticsearch + FluentBit + Kibana) are flexible and powerful open source projects, provides distributed real-time search and analytics tools.</br>

This chart bootstraps a EFK deployment on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager. The chart has the following components,
- Fluent-Bit
- Elasticsearch
- Kibana
