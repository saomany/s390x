# Drone.io

[Drone](http://readme.drone.io/) is a Continuous Integration platform built on container technology.

Currently supported providers:
  - GitHub
  - GitLab
  - Gitea
  - Gogs
  - Bitbucket Cloud
  - Bitbucket Server (Stash)
  - Coding

You may setup the [configurations](http://readme.drone.io/admin/) of the provider later in the configmap.
