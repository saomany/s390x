# Vault Operator
Run and manage Vault on Kubernetes simply and securely.


### Prerequisites

- Kubernetes 1.8+
